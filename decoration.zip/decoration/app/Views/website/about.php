<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>just testing</title>
</head>
<body>
   <h1>Decoration website tdaaaa....</h1>
   <h2>about page</h2>
</body>
</html>